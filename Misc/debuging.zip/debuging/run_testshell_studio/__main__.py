import subprocess
import ctypes
import sys
ctypes.windll.shell32.ShellExecuteW(None,
                                    u"runas",
                                    unicode(sys.executable),
                                    unicode(__file__),
                                    None,
                                    1
                                    )

subprocess.call(['C:\Program Files (x86)\QualiSystems\TestShell\Studio\QsTestShellStudio.exe'],
                shell=True)



