import cloudshell.api.cloudshell_api as api
username = 'admin'
password = 'admin'
server = 'localhost'
domain = 'Global'

NN_ATTRIBUTE_NAME = 'External Host Name'

session = api.CloudShellAPISession(
    username=username,
    password=password,
    domain=domain,
    host=server
)

def find_the_villain(self, reservation_details_data, external_hosts):
    connectors = reservation_details_data.Connectors
    service_aliases = [ser.Alias for ser in reservation_details_data.Services]
    vms = [res.Name for res in external_hosts]
    external_host_connectors = [conn for conn in connectors if conn.Source in vms or conn.Target in vms]
    vlans = []
    for aconnector in external_host_connectors:
        if aconnector.Source in service_aliases and aconnector.Source not in vlans:
            vlans.append(aconnector.Source)
        if aconnector.Target in service_aliases and aconnector.Target not in vlans:
            vlans.append(aconnector.Target)
    if vlans.__len__() != 1:
        VLAN = 'vlan not found'
    else:
        VLAN = vlans[0]
    return VLAN


def get_all_external_hosts(self, session, reservation_details_data, resid):
    external_hosts = []
    reservation_vms_details_raw = [session.GetResourceDetails(res.Name) for res in reservation_details_data.Resources]
    for vm_details in reservation_vms_details_raw:
        attrs = [attr.Value for attr in vm_details.ResourceAttributes if attr.Name == NN_ATTRIBUTE_NAME]
        if attrs:
            external_hosts.append(vm_details)
            # session.WriteMessageToReservationOutput(resid, vm_details.Name)
    return external_hosts

def get_vlan_id_from_name(self, session, res_det, VLAN):
    services = res_det.Services
    vlan_services = [ser for ser in services if ser.Alias == VLAN]
    if vlan_services:
        vlan_ID = [attr.Value for attr in vlan_services[0].Attributes if attr.Name == 'Virtual Network'][0]
    else:
        vlan_ID = None
    return vlan_ID


resid = 'c64d082c-5cab-40ac-81ce-a375c3476f50'
res_det = session.GetReservationDetails(resid).ReservationDescription
ff = find_the_villain('a', res_det, get_all_external_hosts('a', session, res_det, resid))
qq = get_vlan_id_from_name('a', session, res_det, ff)
pass