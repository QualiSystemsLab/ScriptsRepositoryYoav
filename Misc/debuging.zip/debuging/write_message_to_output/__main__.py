import Write_hello_to_output
Write_hello_to_output.run()