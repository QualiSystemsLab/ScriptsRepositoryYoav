import cloudshell.api.cloudshell_api as api
from domain_constants_essity import *
username = 'admin'
password = 'admin'
server = 'localhost'
domain = 'Global'


session = api.CloudShellAPISession(
    username=username,
    password=password,
    domain=domain,
    host=server
)

fff = EssityProducts

pass