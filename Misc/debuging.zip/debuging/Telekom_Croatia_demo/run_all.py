import cloudshell.api.cloudshell_api as api
import cloudshell.helpers.scripts.cloudshell_scripts_helpers as sch
import rest_start_custom_job

username = 'admin'
password = 'admin'
server = 'localhost'
domain = 'Global'
new_server = 'localhost'

session = api.CloudShellAPISession(
    username=username,
    password=password,
    domain=domain,
    host=server
)

all_Dslams = [res.FullName for res in session.FindResources(resourceModel='Ericsson').Resources]
all_CPEs = [res.FullName for res in session.FindResources(resourceModel='Generic CPE').Resources]
job_engine = rest_start_custom_job.rest_handler()
for dslam in all_Dslams:
    for cpe in all_CPEs:
        job_engine.run_job(cpe, dslam)
pass