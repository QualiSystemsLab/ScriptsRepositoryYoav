import requests
import json
import time
login_data = {
    'username': 'admin',
    'password': 'admin',
    'domain': 'Global'
}
class rest_handler():
    def __init__(self):
        self.login = requests.put('http://localhost:9000/API/Auth/Login', data=login_data).text[1:-1]
        self.auth = {
                'Authorization': 'Basic {0}'.format(self.login)
        }

    def run_job(self, CPE, DSLAM):
        job_data ={
                    "name": "job_with_{0}_and_{1}".format(CPE, DSLAM),
                    "description": "",
                    "executionServers": [],
                    "loggingProfile": "All",
                    "estimatedDuration": "15",
                    "stopOnFail": "false",
                    "stopOnError": "false",
                    "tests": [
                        {
                            "TestPath": "TestShell\\Tests\\Shared\\ASharedTest",
                            "TestDuration": "5",
                            "Parameters": []
                        }
                    ],
                    "Topology": {
                        "Name": "Hrvatski Telekom Demo",
                        "GlobalInputs": [
                            {"Name": "CPE Name", "Value": "{}".format(CPE)},
                            {"Name": "DSLAM Name", "Value": "{}".format(DSLAM)}
                        ],
                        "RequirementsInput": [],
                        "AdditionalInput": []
                    },
                    "durationTimeBuffer": "2",
                    "emailNotifications": "All",
                    "type": "TestShell"
            }

        job_data_json = json.dumps(job_data)
        new_job = requests.post('http://localhost:9000/API/Scheduling/Queue',
                                headers=self.auth,
                                json=json.loads(job_data_json))
        if new_job.status_code == 400:
            print new_job.text
        elif new_job.status_code == 200:
            return "success"
