class EssityProject():

    def __init__(self, domain_name='', project='', publication_id='', language_code='',
                 search_code='', catalog_code='', octopus_project='', feed_name='', package_id=''):
        self.domain_name = domain_name
        self.project = project
        self.publication_id = publication_id
        self.language_code = language_code
        self.search_code = search_code
        self.catalog_code = catalog_code
        self.octopus_project = octopus_project
        self.feed_name = feed_name
        self.package_id = package_id


EssityProducts = []
EssityProducts.append(EssityProject(
    domain_name='TORK',
    project='TORK',
    publication_id='38',
    language_code='en-US',
    search_code='Tork_Na',
    catalog_code='US_Local',
    feed_name='feeds-nexus',
    package_id='TOL.Web.Demo'
))
EssityProducts.append(EssityProject(
    domain_name='TOL',
    project='TORK',
    publication_id='38',
    language_code='en-US',
    search_code='Tork_Na',
    catalog_code='US_Local',
    feed_name='feeds-nexus',
    package_id='TOL.Web.Demo'
))
