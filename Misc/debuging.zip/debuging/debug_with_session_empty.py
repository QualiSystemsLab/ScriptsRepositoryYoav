import cloudshell.api.cloudshell_api as api
import cloudshell.helpers.scripts.cloudshell_scripts_helpers as sch

username = 'admin'
password = 'admin'
server = 'localhost'
domain = 'Global'
new_server = 'localhost'

session = api.CloudShellAPISession(
    username=username,
    password=password,
    domain=domain,
    host=server
)
qq = session.GetResourceDetails('DUT 3')
session.SetResourceSharedState(
    reservationId='3370d76a-f21b-42c6-8d75-459c374b9af4',
    resourcesFullName=['DUT 3'],
    isShared=True
)
pass
