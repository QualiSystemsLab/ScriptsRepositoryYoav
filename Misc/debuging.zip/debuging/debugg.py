__author__ = 'yoav.e'

# import cloudshell.api.cloudshell_api as api_7
# username = 'admin'
# password = 'admin'
# server_6 = 'q1.cisco.com'
# server_7 = 'qs.cisco.com'
# O_domain = 'Global'
# N_domain = 'Global'
# session_7 = api_7.CloudShellAPISession(server_7, username, password, N_domain)
# all_switches = session_7.FindResources(resourceFamily='switch')
# all_firewalls = session_7.FindResources(resourceFamily='Firewalls')
# all_ssps = session_7.FindResources(resourceFamily='SSP Chassis')
# all_vms = session_7.FindResources(resourceFamily='SSP CI Regression VMs' , maxResults=2000)
# all_terms = session_7.FindResources(resourceFamily='Terminal Server')
# all_gens = session_7.FindResources(resourceFamily='Generic App Family')
# all_vrouter = session_7.FindResources(resourceFamily='Virtual Machine Instance')
# all_FMC = session_7.FindResources(resourceFamily='VMs')
# all_WSA = session_7.FindResources(resourceFamily='Web Security Appliance')
# rd = session_7.GetTopologyDetails('SSP SJC Topologies\\BS2QP migration').Resources
# connects = []
# for r in rd:
#     for c in r.Connections:
#         connects.append(c.FullPath)
# for q in connects:
#     print q
# pass


# import win_unc
import os
import shutil
# from multiprocessing.pool import ThreadPool
# from threading import Lock

def go_through_folder(j, unc_path, loc_path, resid):
    curr_path = unc_path + '\\' + j + '\\'
    print curr_path
    for ROOT, DIR, FILES in os.walk(curr_path):
        if ROOT.__contains__(resid):
            new_loc_dir = loc_path + '\\' + j
            os.mkdir(new_loc_dir)
            for f in FILES:
                file_path = ROOT + '\\' + f
                shutil.copy(file_path, new_loc_dir)
            break

resid = 'ab03e40b-15bc-41ea-a79b-5ecd2a7715cb'
# unc_path = r'\\qexec7-ssp-sjc.cisco.com\c$\programdata\qualisystems\venv'
unc_path = r'c:\programdata\qualisystems\venv'
loc_path = r'C:\temp\autlog'
# creds = win_unc.UncCredentials('quali.gen@cisco.com', 'Password3')
# authz_unc = win_unc.UncDirectory(unc_path, creds)
# conn = win_unc.UncDirectoryConnection(authz_unc)
# conn.connect()
jj = os.listdir(unc_path)
# pool = ThreadPool(len(jj))
# lock = Lock()
for j in jj:
    # pool.apply_async(go_through_folder, (j, unc_path, loc_path, resid))
    go_through_folder(j, unc_path, loc_path, resid)
# pool.close()
# pool.join()
# conn.disconnect()

pass