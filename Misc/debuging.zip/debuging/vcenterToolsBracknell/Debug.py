# debug
import cloudshell.helpers.scripts.cloudshell_dev_helpers as dev_helpers
import vmwareConsole

resid = 'd2a465f7-a75d-4fdb-8e5c-b97c5031a85d'
Resource_Name = 'IxVM 8.40 EA - Ixia Virtual Test Appliance_bd16-a85d'
dev_helpers.attach_to_cloudshell_as(
    user='admin',
    password='admin',
    domain='Global',
    reservation_id=resid,
    server_address='localhost',
    resource_name=Resource_Name
)
q = vmwareConsole.vmware_console()
q.main()
pass