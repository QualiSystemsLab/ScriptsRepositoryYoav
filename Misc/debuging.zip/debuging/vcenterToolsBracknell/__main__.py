from vmwareConsole import vmware_console
qq = vmware_console()
qq.main()
