import atexit
import OpenSSL
import ssl
import sys
import time
import json
import os

from pyVim.connect import Disconnect, SmartConnectNoSSL
from pyVmomi import vim
import cloudshell.api.cloudshell_api as api
import cloudshell.helpers.scripts.cloudshell_scripts_helpers as helpers

# reservation_details = json.loads(os.environ["RESERVATIONCONTEXT"])
# resource_context = json.loads(os.environ['RESOURCECONTEXT'])
# connectivity_details = json.loads(os.environ["QUALICONNECTIVITYCONTEXT"])

class vmware_console():
    def __init__(self):
        pass

    def get_vm(self, content, name):
        try:
            name = unicode(name, 'utf-8')
        except TypeError:
            pass

        vm = None
        container = content.viewManager.CreateContainerView(
            content.rootFolder, [vim.VirtualMachine], True)

        for c in container.view:
            if c.name == name:
                vm = c
                break
        return vm

    def main(self):
        self.get_cs_data()
        port = 443

        try:
            si = SmartConnectNoSSL(host=self.host,
                                   user=self.user,
                                   pwd=self.pwd)
        except Exception as e:
            print 'Could not connect to vCenter host'
            print repr(e)
            sys.exit(1)

        atexit.register(Disconnect, si)
        datacenter = si.content.rootFolder.childEntity[0]
        content = si.RetrieveContent()
        pass

    def get_cs_data(self):
        self.session = helpers.get_api_session()
        # self.session = api.CloudShellAPISession(host=connectivity_details['serverAddress'],
        #                                    token_id=connectivity_details['adminAuthToken'],
        #                                    domain=reservation_details['domain'])
        resource_context = helpers.get_resource_context_details_dict()
        self.name = resource_context['name']
        res_dets = self.session.GetResourceDetails(resource_context['name'])
        self.host = self.session.GetResourceDetails(res_dets.VmDetails.CloudProviderFullName).RootAddress
        cp_dets = self.session.GetResourceDetails(res_dets.VmDetails.CloudProviderFullName)
        self.user = [attr.Value for attr in cp_dets.ResourceAttributes if attr.Name == 'User'][0]
        self.pwd = self.session.DecryptPassword(
            [attr.Value for attr in cp_dets.ResourceAttributes if attr.Name == 'Password'][0]).Value