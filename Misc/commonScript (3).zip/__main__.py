import CommonScript
mycommonscript = CommonScript.CommonScriptClass()
mycommonscript.run_ps_script()

