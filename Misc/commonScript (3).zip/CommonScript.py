import cloudshell.helpers.scripts.cloudshell_scripts_helpers as helpers
import os
from cloudshell.api.cloudshell_api import InputNameValue


class CommonScriptClass:
    def __init__(self):
        pass

    def run_ps_script(self):
        session = helpers.get_api_session()
        reservation_context_details = helpers.get_reservation_context_details()
        # try:
        #     decrypted_pass = \
        #         session.DecryptPassword(helpers.get_user_param('password')).Value
        # except:
        #     decrypted_pass=helpers.get_user_param('password')

        tridion_resource_details = session.GetResourceDetails\
            ([res.Name for res in session.GetReservationDetails(helpers.get_reservation_context_details().id).ReservationDescription.Resources if res.ResourceModelName == 'Tridion'][0])
        tridion_ip = tridion_resource_details.Address
        tridion_user = [attr.Value for attr in tridion_resource_details.ResourceAttributes if attr.Name == 'User'][0]
        tridion_password = session.DecryptPassword([attr.Value for attr in tridion_resource_details.ResourceAttributes if attr.Name == 'Password'][0]).Value


        session.WriteMessageToReservationOutput(reservation_context_details.id,'IP: ' + tridion_ip)
        session.WriteMessageToReservationOutput(reservation_context_details.id, 'user: ' + tridion_user)

        source_control_prefix = session.GetResourceDetails(resourceFullPath='Essity_SDL_BitBucket').Address
        script_name = helpers.get_user_param('ps_script')
        if script_name.__contains__(','):
            scripts = script_name.split(',')
        else:
            scripts = [script_name]
        for script in scripts:

            full_path_to_run = source_control_prefix + '/{0}.ps1'.format(script)

            session.WriteMessageToReservationOutput(reservation_context_details.id, 'running Script from: {0}'.format(full_path_to_run))
            tridon_resource_name = self.get_tridon_resource(session, helpers.get_reservation_context_details().id)

            if not tridon_resource_name:
                return

            address_input, user_input, password_input, environment_params = self._extract_tridon_data(
                helpers.get_reservation_context_details().id, session, tridon_resource_name)

            commandInputs = [InputNameValue('script_url',full_path_to_run),
                             InputNameValue('ip', tridion_ip),
                             InputNameValue('user', tridion_user),
                             InputNameValue('password', tridion_password),
                             # InputNameValue('parameters', environment_params),
                             environment_params,
                             InputNameValue('use_ps', '')
                             ]

            session.WriteMessageToReservationOutput(reservation_context_details.id,
                                                    'Running {0} powershell script... '.format(script))
            session.ExecuteCommand(reservation_context_details.id,
                                   targetName='ScriptOrchestrator',
                                   targetType='Service',
                                   commandName='run_script',
                                   commandInputs=commandInputs)

    def _extract_tridon_data(self, reservation_id, api, tridon_resource_name):

        tridon = api.GetResourceDetails(tridon_resource_name)
        user \
            = self._first_or_default(tridon.ResourceAttributes, lambda attribute: attribute.Name == 'User').Value
        password \
            = self._first_or_default(tridon.ResourceAttributes, lambda attribute: attribute.Name == 'Password').Value

        decryptedPass = api.DecryptPassword(password).Value
        environment_params = InputNameValue('parameters', 'IN_USER={user};IN_PASS={password}'.format(user=user,
                                                                                                     password=decryptedPass))

        address = tridon.Address
        return InputNameValue('ip', address), InputNameValue('user', user), InputNameValue('password',
                                                                                           decryptedPass), environment_params

    def get_tridon_resource(self, api, reservation_id):
        reservation_description = api.GetReservationDetails(reservation_id).ReservationDescription
        tridon_resource \
            = self._first_or_default(reservation_description.Resources,
                                     lambda resource: resource.Name.startswith('tridion'))

        if not tridon_resource:
            return None

        return tridon_resource.Name

    @staticmethod
    def _first_or_default(collection, predicate):
        return [item for item in collection if predicate(item)][0]

