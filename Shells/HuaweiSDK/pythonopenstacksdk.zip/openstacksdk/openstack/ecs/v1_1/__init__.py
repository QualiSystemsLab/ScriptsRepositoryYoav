#! /usr/bin/env python
# -*- coding:utf-8 -*-

# this is ecs service v1.1 module

def main():
    pass


if __name__ == '__main__':
    main()
