Bare Metal Resources
=====================

.. toctree::
   :maxdepth: 1

   v1/driver
   v1/chassis
   v1/node
   v1/port
   v1/port_group
