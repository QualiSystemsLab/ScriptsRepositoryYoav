Telemetry Resources
===================

.. toctree::
   :maxdepth: 1

   v2/capability
   v2/meter
   v2/resource
   v2/sample
   v2/statistics
