openstack.cts.v1.tracker
========================

.. automodule:: openstack.cts.v1.tracker

The Tracker Class
-----------------

The ``Traker`` class inherits from
    :class:`~openstack.cts.v1.ctsresource.Resource`.

.. autoclass:: openstack.cts.v1.tracker.Tracker
   :members:
