openstack.cluster.v1.profile
============================

.. automodule:: openstack.cluster.v1.profile

The Profile Class
-----------------

The ``Profile`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.profile.Profile
   :members:
