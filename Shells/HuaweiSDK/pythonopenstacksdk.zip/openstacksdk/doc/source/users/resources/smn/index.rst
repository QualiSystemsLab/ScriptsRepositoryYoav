SMN Resources
=============

.. toctree::
   :maxdepth: 1

   v2/message_template.rst
   v2/subscription.rst
   v2/topic.rst
