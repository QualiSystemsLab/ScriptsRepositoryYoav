openstack.network.v2.qos_minimum_bandwidth_rule
===============================================

.. automodule:: openstack.network.v2.qos_minimum_bandwidth_rule

The QoSMinimumBandwidthRule Class
---------------------------------

The ``QoSMinimumBandwidthRule`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.qos_minimum_bandwidth_rule.QoSMinimumBandwidthRule
   :members:
