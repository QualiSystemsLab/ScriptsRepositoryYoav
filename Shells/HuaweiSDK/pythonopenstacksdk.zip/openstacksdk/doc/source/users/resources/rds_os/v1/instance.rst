openstack.rds_os.v1.instance
============================

.. automodule:: openstack.rds_os.v1.instance

The Instance Class
------------------

The ``Instance`` class inherits from
    :class:`~openstack.rds_os.v1.rds_osresource.Resource`.

.. autoclass:: openstack.rds_os.v1.instance.Instance
   :members:
