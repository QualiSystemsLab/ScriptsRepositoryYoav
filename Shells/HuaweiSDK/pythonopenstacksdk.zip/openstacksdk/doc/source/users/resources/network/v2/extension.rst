openstack.network.v2.extension
==============================

.. automodule:: openstack.network.v2.extension

The Extension Class
-------------------

The ``Extension`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.extension.Extension
   :members:
