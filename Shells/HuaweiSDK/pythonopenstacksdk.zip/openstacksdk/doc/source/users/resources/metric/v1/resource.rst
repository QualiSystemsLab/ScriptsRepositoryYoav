openstack.metric.v1.resource
============================

.. automodule:: openstack.metric.v1.resource

The Generic Class
-----------------

The ``Generic`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.metric.v1.resource.Generic
   :members:
