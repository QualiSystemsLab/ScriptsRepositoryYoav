openstack.network.v2.listener
=============================

.. automodule:: openstack.network.v2.listener

The Listener Class
------------------

The ``Listener`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.listener.Listener
   :members:
