openstack.cluster.v1.action
===========================

.. automodule:: openstack.cluster.v1.action

The Action Class
----------------

The ``Action`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.action.Action
   :members:
