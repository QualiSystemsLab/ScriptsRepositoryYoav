Compute Resources
=================

.. toctree::
   :maxdepth: 1

   v2/extension
   v2/flavor
   v2/image
   v2/keypair
   v2/limits
   v2/server
   v2/server_interface
   v2/server_ip
