openstack.metric.v1.archive_policy
==================================

.. automodule:: openstack.metric.v1.archive_policy

The ArchivePolicy Class
-----------------------

The ``ArchivePolicy`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.metric.v1.archive_policy.ArchivePolicy
   :members:
