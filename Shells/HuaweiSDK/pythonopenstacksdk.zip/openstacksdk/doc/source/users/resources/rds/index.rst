RDS Resources
=============

.. toctree::
   :maxdepth: 1

   v1/backup.rst
   v1/datastore.rst
   v1/flavor.rst
   v1/instance.rst
