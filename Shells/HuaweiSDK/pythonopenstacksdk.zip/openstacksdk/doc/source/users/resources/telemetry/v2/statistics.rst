openstack.telemetry.v2.statistics
=================================

.. automodule:: openstack.telemetry.v2.statistics

The Statistics Class
--------------------

The ``Statistics`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.telemetry.v2.statistics.Statistics
   :members:
