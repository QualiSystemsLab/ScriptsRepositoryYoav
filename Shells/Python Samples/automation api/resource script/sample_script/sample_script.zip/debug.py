import cloudshell.helpers.scripts.cloudshell_dev_helpers as dev_helpers
# dev_helpers.attach_to_cloudshell_as(
#     user=username,
#     password=password,
#     domain=domain,
#     server_address=server,
#     reservation_id='c924fc0d-9a7b-4c83-baab-2f718b5f8667'
# )