__author__ = 'yoav.e'
from emailSender import email_sender
qq = email_sender()
qq.send()
