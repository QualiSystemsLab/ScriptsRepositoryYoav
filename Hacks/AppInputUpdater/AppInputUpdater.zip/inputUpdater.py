import json
import os
import cloudshell.api.cloudshell_api as api
import drivercontext


# Production
reservation_details = json.loads(os.environ["RESERVATIONCONTEXT"])
resource_context = json.loads(os.environ['RESOURCECONTEXT'])
connectivity_details = json.loads(os.environ["QUALICONNECTIVITYCONTEXT"])


username = connectivity_details['adminUser']
password = connectivity_details['adminPass']
server = connectivity_details['serverAddress']
domain = reservation_details['domain']

session = api.CloudShellAPISession(server, username, password, domain)
edit_list = []



class InputUpdater:
    def __init__(self):
        pass

    def initialize(self, context):
        """
        :type context: drivercontext.InitCommandContext
        """
        pass

    def change_app_input_value(AppName, AppModel, DeployModel, attr_name, attr_value):
        edit_vals = api.ApiEditAppRequest(AppName,
                                          AppName,
                                          '',
                                          api.AppDetails(ModelName=AppModel,
                                                         Attributes=[],
                                                         Driver=''),
                                          api.DefaultDeployment(DeployModel,
                                                                api.Deployment(
                                                                    [api.NameValuePair(attr_name, attr_value)]
                                                                ),
                                                                Installation=None
                                                                )
                                          )
        edit_list.append(edit_vals)
        qq = session.EditAppsInReservation(
            reservationId=reservation_details['id'],
            editAppsRequests=edit_list
        )
        return qq