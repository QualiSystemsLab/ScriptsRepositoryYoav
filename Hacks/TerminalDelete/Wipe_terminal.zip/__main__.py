__author__ = 'yoav.e'
import TerminalWipe
TerminalWipe.Terminals_wipe()