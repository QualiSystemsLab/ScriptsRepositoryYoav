__author__ = 'yoav.e'
import activateConsole
activateConsole.activate_console()