from setuptools import setup, find_packages

setup(name='retrying_with_qslogger',
      version='0.0.12',
      description='',
      author='',
      url='',
      license='',
      classifiers=['Development Status :: 4 - Beta',
                   'Environment :: Console',
                   'Intended Audience :: End Users/Desktop',
                   'Programming Language :: Python :: 2.7',
                   'License :: OSI Approved :: License'],
      packages=find_packages(),
      package_data={'': ['*.txt']},
      include_package_data=True,
      # entry_points={'console_scripts': ['Retrying_with_qslogger = Retrying_qslogger:retry']},
      install_requires=["six", "cloudshell-core==2.2.180"])