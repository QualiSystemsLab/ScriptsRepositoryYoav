# from cloudshell.workflow.orchestration.sandbox import Sandbox
# from cloudshell.workflow.orchestration.setup.default_setup_orchestrator import DefaultSetupWorkflow
import driver
from cloudshell.shell.core.driver_context import InitCommandContext, ResourceCommandContext

from cloudshell.helpers.scripts.cloudshell_dev_helpers import attach_to_cloudshell_as
import cloudshell.helpers.scripts.cloudshell_scripts_helpers as sh
import cloudshell.api.cloudshell_api as api
DEBUG_MODE = True
attach_to_cloudshell_as(user="yoav.e",
                        password="1234",
                        domain="Global",
                        reservation_id="84784ee5-75cf-4f66-af37-875dc8614447",
                        server_address="localhost",
                        resource_name='corevsrx-b97e2919')


session = sh.get_api_session()
token = session.token_id

reservation_context = sh.get_reservation_context_details()
reservation_context.reservation_id = reservation_context.id

connectivity_context = sh.get_connectivity_context_details()
connectivity_context.admin_auth_token = token

context = ResourceCommandContext(
    connectivity=connectivity_context,
    resource=sh.get_resource_context_details(),
    reservation=reservation_context,
    connectors=''
)



# context = ResourceCommandContext(connectivity=sh.get_connectivity_context_details(),
#                                  reservation=sh.get_reservation_context_details(),
#                                  resource=sh.get_resource_context_details(),
#                                  connectors=None
#                                  )

init_context = InitCommandContext(connectivity=sh.get_connectivity_context_details(),
                                  resource=sh.get_resource_context_details())


my_driver = driver.VsrxDriver()
my_driver.initialize(init_context)
my_driver.poll(context)
# my_driver.configure(context)
pass